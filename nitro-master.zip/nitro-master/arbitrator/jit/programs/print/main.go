// Copyright 2022, Offchain Labs, Inc.
// For license information, see https://github.com/nitro/blob/master/LICENSE

package main

func main() {
	// what follows is a heartfelt poem about spiders, compilers,
	// and the language that brings them together

	println("itsy bitsy spider /\\oo/\\ made 407614 lines 🎵")
	println("that's because it's golang and there's a huge runtime 🎵")
	println("there's more than just 4 printlns since we might reflect 🎵")
	println("that's the state of golang, what would you expect? 🎵")
}
